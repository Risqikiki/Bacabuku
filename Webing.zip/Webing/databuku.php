<?php
require 'function.php';
$artikel    = query("SELECT * FROM artikel");


if (isset($_POST["cari"]) ) {
  $artikel = cari($_POST["keyword"]);
}
?>
<!DOCTYPE html">
<html>
<head>
<title>Halaman Admin</title>
</head>
<style>
  @charset "utf-8";

form, fieldset, legend{margin:0; padding:0; border:none;}
legend{display:none;}

#container #respond{display:block; width:100%;}
#container #respond input{width:170px; padding:2px; border:1px solid #CCCCCC; margin:5px 5px 0 0;}
#container #respond textarea{width:98%; border:1px solid #CCCCCC; padding:2px; overflow:auto;}
#container #respond p{margin:5px 0;}
#container #respond #submit, #container #respond #reset{margin:0; padding:5px; color:#666666; background-color:#F7F7F7; border:1px solid #CCCCCC;}

#footer form{display:block; width:300px; margin:0; padding:10px 0; border:none;}
#footer input{display:block; float:left; width:245px; margin:0 5px 0 0; padding:5px; color:#666666; background-color:#FFFFFF; border:1px solid #DBDBDB; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;}
#footer input#news_go{width:auto; height:auto; margin:0; padding:4px;}

html{overflow-y:scroll;}
body{margin:0; padding:0; font-size:12px; font-family:verdana, Arial, Helvetica, sans-serif; color:#FFFFFF; background-color:#333333;}

.justify{text-align:justify;}
.bold{font-weight:bold;}
.center{text-align:center;}
.right{text-align:right;}
.nostart{margin:0; padding:0; list-style-type:none;}

.clear{clear:both;}
br.clear{clear:both; margin-top:-15px;}

a{outline:none; text-decoration:none;}

.fl_left, .imgl{float:left;}
.fl_right, .imgr{float:right;}

img{margin:0; padding:0; border:0;}
.imgl, .imgr{border:1px solid #666666; padding:5px; color:#666666; background-color:#FFFFFF;}
.imgl{margin:0 15px 0 0; clear:left;}
.imgr{margin:0 0 15px 15px; clear:right;}

div.wrapper{display:block; width:100%; margin:0; text-align:left;}
div.wrapper h1, div.wrapper h2, div.wrapper h3, div.wrapper h4, div.wrapper h5, div.wrapper h6{margin:0 0 15px 0; padding:0; font-size:20px; font-weight:normal; font-family:Georgia, "Times New Roman", Times, serif;}
.col1, .col1 a{color:#FFFFFF; background-color:#D51D29;}
.col2{color:#FFFFFF; background-color:#000000;}
.col3{color:#999999; background-color:#4C4C4E; border-bottom:1px solid #D51D29;}
.col4{color:#FFFFFF; background-color:#232323; border-bottom:1px solid #D51D29;}
.col4 a{color:#FFFFFF; background-color:#232323;}
.col5{color:#666666; background-color:#FFFFFF;}
.col5 a{color:#D51D29; background-color:#FFFFFF;}
.col6{color:#98989A; background-color:#2D2B2B; border-top:1px solid #D51D29;}
.col6 a{color:#CCCCCC; background-color:#2D2B2B;}
.col7, .col7 a{color:#605B5B; background-color:#333333;}


#topbar, #header, #topnav, #intro, #breadcrumb, #container, #footer, #copyright{display:block; position:relative; width:960px; margin:0 auto;}


#topbar{padding:10px 0;}
#topbar p{float:left; margin:0; padding:0;}
#topbar ul{float:right; margin:0; padding:0; list-style:none;}
#topbar li{display:inline; margin:0 8px 0 0; padding:0 10px 0 0; border-right:1px solid #FFFFFF;}
#topbar li.last{margin-right:0; padding-right:0; border:none;}


#header{padding:20px 0;}
#header h1, #header p{margin:0; padding:0;}
#header .fl_left{display:block; float:left; width:400px;}
#header .fl_right{display:block; float:right; width:468px;}
#header h1{margin:0; font-size:36px; border:none;}
#header h1 a{color:#FFFFFF; background-color:#000000;}


#breadcrumb{padding:20px 0;}
#breadcrumb ul{margin:0; padding:0; list-style:none;}
#breadcrumb ul li{display:inline;}
#breadcrumb ul li.current a{text-decoration:underline;}

#container{padding:20px 0; line-height:1.4em;}
#container h1, #container h2, #container h3, #container h4, #container h5, #container h6{padding-bottom:8px; border-bottom:1px dotted #CCCCCC;}
#content{display:block; float:left; width:600px;}


#column{display:block; float:right; width:300px;}
.flickrbox ul{margin:0; padding:0; list-style:none;}
.flickrbox li{display:block; float:left; width:80px; height:80px; margin:0 15px 15px 0; padding:4px; color:#666666; background-color:#FFFFFF; border:1px solid #CCCCCC;}
.flickrbox li.last{margin-right:0;}
#column .holder, #column #featured{display:block; width:300px; margin-bottom:20px;}
#column .holder h2.title{display:block; width:100%; height:65px; margin:0; padding:15px 0 0 0; font-size:20px; line-height:normal; border-bottom:1px dashed #666666;}
#column .holder h2.title img{float:left; margin:-15px 8px 0 0; padding:5px; border:1px solid #666666;}
#column div.imgholder{display:block; width:290px; margin:0 0 10px 0; padding:4px; color:#666666; background-color:#FFFFFF; border:1px solid #CCCCCC;}
#column .holder p.readmore{display:block; width:100%; font-weight:bold; text-align:right; line-height:normal;}

#column #featured a{color:#666666; background-color:#F9F9F9;}
#column #featured ul, #column #featured h2, #column #featured p{margin:0; padding:0; list-style:none;}
#column #featured a{color:#D51D29; background-color:#F9F9F9;}
#column #featured li{display:block; width:250px; margin:0; padding:20px 25px; color:#666666; background-color:#F9F9F9;}
#column #featured li p.imgholder{display:block; width:240px; height:90px; margin:20px 0 15px 0; padding:4px; border:1px solid #CCCCCC;}
#column #featured li h2{margin:0; padding:0 0 14px 0; font-weight:normal; font-family:Georgia, "Times New Roman", Times, serif; line-height:normal; border-bottom:1px dashed #666666;}
#column #featured p.readmore{display:block; width:100%; margin-top:15px; font-weight:bold; text-align:right; line-height:normal;}
#column #latestnews{display:block; width:100%; margin:0; padding:0; list-style:none;}
#column #latestnews li{display:block; margin:0 0 20px 0; padding:0 0 15px 0; border-bottom:1px dotted #CCCCCC;}
#column #latestnews li.last{margin-bottom:0;}
#column #latestnews p{margin:0 0 5px 0; padding:0;}
#column #latestnews p.readmore{margin:0; padding:0;}
#column #latestnews .imgl{margin:0 10px 10px 0; padding:4px;}

#footer{padding:20px 0;}
#footer h2{padding-bottom:8px; border-bottom:1px dotted #999999;}
#footer p, #footer ul, #footer a{margin:0; padding:0; font-weight:normal; list-style:none; line-height:normal;}
#footer .footbox{display:block; float:right; width:190px; margin:0 0 0 30px; padding:0;}
#footer li{margin-bottom:3px;}
#footer .last{margin:0;}
#newsletter{display:block; float:left; width:300px;}

#copyright{padding:15px 0;}
#copyright p{margin:0; padding:0;}

#topnav{padding:15px 0; z-index:1000;}
#topnav ul, #topnav li{margin:0; padding:0; list-style:none; font-size:14px; font-family:Georgia, "Times New Roman", Times, serif;}
#topnav li{float:left; margin-right:30px;}
#topnav li li{margin-right:0;}
#topnav li span{display:block; font-size:12px; font-weight:bold; font-family:Arial, Helvetica, sans-serif; text-transform:lowercase; color:#999999; background-color:#4C4C4E; font-weight:normal; line-height:normal; margin:0; padding:0;}
#topnav li a:link, #topnav li a:visited, #topnav li a:hover{display:block; margin:0; padding:0; color:#FFFFFF; background-color:#4C4C4E; text-transform:uppercase; font-weight:bold;}
#topnav ul ul li a:link, #topnav ul ul li a:visited{border:none;}
#topnav li a:hover, #topnav li.active a{color:white; background-color:#4C4C4E;}
#topnav li li a:link, #topnav li li a:visited{width:150px; float:none; margin:0; padding:7px 10px; font-size:12px; font-weight:normal; color:#FFFFFF; background-color:#4C4C4E; border:none;}
#topnav li li a:hover{color:red; background-color:#4C4C4E;}
#topnav ul ul{z-index:9999; position:absolute; left:-999em; height:auto; width:170px;}
#topnav ul ul a{width:140px;}
#topnav li:hover ul{left:auto;}
#topnav li:hover{position:static;}
#topnav li.last{margin-right:0;}

#column .subnav{display:block; width:250px; padding:25px; background-color:#F9F9F9; margin-bottom:30px;}
#column .subnav h2{margin:0 0 20px 0; padding:0 0 14px 0; font-size:20px; font-weight:normal; font-family:Georgia, "Times New Roman", Times, serif; color:#666666; background-color:#F9F9F9; line-height:normal; border-bottom:1px dotted #666666;}
#column .subnav ul{margin:0; padding:0; list-style:none;}
#column .subnav li{margin:0 0 3px 0; padding:0;}
#column .subnav ul ul, #column .subnav ul ul ul, #column .subnav ul ul ul ul, #column .subnav ul ul ul ul ul{border-top:none; padding-top:0;}
#column .subnav a{display:block; margin:0; padding:5px 10px 5px 20px; color:#777777; background:url("images/red_file.gif") no-repeat 10px center #F9F9F9; text-decoration:none; border-bottom:1px dotted #666666;}
#column .subnav a:hover{color:#D51D29; background-color:#F9F9F9;}
#column .subnav ul ul a, #column .subnav ul ul ul a, #column .subnav ul ul ul ul a, #column .subnav ul ul ul ul ul a{background:url("images/black_file.gif") no-repeat #F9F9F9;}
#column .subnav ul ul a{padding-left:40px; background-position:30px center;}
#column .subnav ul ul ul a{padding-left:50px; background-position:40px center;}
#column .subnav ul ul ul ul a{padding-left:60px; background-position:50px center;}
#column .subnav ul ul ul ul ul a{padding-left:70px; background-position:60px center;}


.smk { margin-left: 0px; width: 150px; height: 150px; float: right; margin-right: 20px}
.rpl { margin-right: 150px; margin-left: 45px; width: auto; height: 150px; background-color: rgb(255, 255, 255); }


.search {
    margin-left: 600px;
    margin-top: -55px;
}
input[type=text] {
    margin-top: -30px;
    color: white;
    width: 300px;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: rgba(0, 0, 0, 0.7);
    background-size: 20px;
    padding: 7px 20px 7px 10px;
}

.button {    
    padding: 7px 13px;
    background-color: lime;
    border-color: lime;
    border-radius: 7px
  }

</style>
<body id="top">
<div class="wrapper col1">
  <div id="topbar">
    <p>Whatsapp: +62 856-4730-1409 | EMail: gilangmobile157@.com</p>
    <ul>
      <li class="last"><a href="logout.php"; onclick="return confirm('Apakah Anda Yakin Ingin Keluar?')";>Logout</a></li>
    </ul>
    <br class="clear" />
  </div>
</div>
<!-- batas -->
<div class="wrapper col2">
  <div id="header">
    <div class="fl_left">
      <h1><a>Artikel Web</a></h1>
      <p>Halaman Admin</p>
    </div>
    <br class="clear" />
<form action="" method="post" class="search">
 <a>Search Data</a><br><br>
  <input type="text" name="keyword" size="40"  placeholder="Masukan Keyword..." autocomplete="off">
  <button type="submit" name="cari" class="button">Cari</button>

</form>
  </div>
</div>
<!-- batas -->
<div class="wrapper col3">
  <div id="topnav">
    <ul>
      <li><a href="homepage.php">Homepage</a><span>Halaman Admin</span></li>
      <li><a href="databuku.php">Data Artikel</a><span>Halaman Data Artikel</span></li>
      <li class="active"><a href="datapengunjung.php">Data Pengunjung</a><span>Halaman Data Pengunjung</span></li>
      <li class="last"><a href="datakomentar.php">Data Komentar</a><span>Halaman Data Komentar</span></li>
    </ul>
    <br class="clear" />
  </div>
</div>
<!--batas -->
<div class="wrapper col5">
  <div id="container">

<h2 style="font-size: 30px;">Data Artikel</h2>
<h1 style="font-size: 20px;"><a href="tambahartikel.php">Tambah Data</a></h1>
<table border="1" cellpadding="10" cellspacing="0" style="color: black;">
  <tr>
    <th>id</th>
    <th>Aksi</th>
    <th>Judul</th>
    <th>Artikel</th>
  </tr>
<?php $i = 1; ?>
<?php foreach ($artikel as $row) : ?>
  <tr>
    <td><?= $i; ?></td>
    <td>
      <a href="update.php?id=<?= $row["id"]; ?>">ubah</a>
      <a href="proses_hapus.php?id=<?= $row["id"]; ?>"
      onclick="return confirm('Yakin Ingin Menghapus Data Ini?');">hapus</a>
    </td>
    <td><?= $row["judul"]?></td>
    <td><?= $row["artikel"]?></td>
  </tr>
  
  <?php $i++; ?>
<?php endforeach; ?>

</table>
</table>
</div>
</div>
<!-- batas -->
<div class="wrapper col6">
  <div id="footer">
    <div id="newsletter">
      <h2>Tentang Saya !</h2>
      <p>Risqi Ardiansyah</p>
      <p>X Rekayasa Perangkat Lunak 2</p>
      <p>SMK Negeri 1 Bawang</p>
    </div>
    <div class="footbox">
      <h2>Fungsi Halaman</h2>
      <ul>
        <li><a>Mengupdate</a></li>
        <li><a>Mendelete</a></li>
        <li><a>Mencari</a></li>
        <li><a>Data Dalam Web</a></li>
      </ul>
    </div>
    <div class="footbox">
      <h2></h2>
      <ul>
        <li><a><img class="rpl" src="rpl.png"></a></li>
      </ul>
    </div>
    <div class="footbox">
      <h2></h2>
      <ul>
        <li><a><img class="smk" src="SMK N 1 Bawang.jpg"></a></li>
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- batas -->
<div class="wrapper col7">
  <div id="copyright">
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a>Banjarnegara</a></p>
    <p class="fl_right">Dibuat oleh <a>Risqi Ardiansyah</a></p>
    <br class="clear" />
  </div>
</div>
</body>
</html>