<?php 
	session_start();
	if (isset($_SESSION['user'])) {
		header("LOCATION:admin.php");
	}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style>
body {
		margin: 0 auto;
		background-image: url(bgwebb.jpg);
		background-repeat: no-repeat;
		background-size: 100% 720px;
	}

h1 {
	text-align: center;
	font-size: 50px;
}

.container {
	width: 550px;
	height: 450px;
	text-align: center;
	background-color: rgba(200,200,200,0.7);
	border-radius: 4px;
	margin: 0 auto;
	margin-top: 50px;
}
.container img {
	width: 120px;
	height: 120px;
	margin-top: -60px;
	margin-bottom: 30px;

}
input[type="text"],input[type=password]{
	height: 45px;
	width: 300px;
	font-size: 16px;
	border: none;
	margin-bottom: 20px;
	border-radius: 4px;
	background-color: #fff;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;

}

p {
	text-align: center;
	background-color: white;
	margin-top: 200px;
	font-size: 20px;
	height: 100px;
}

p1 {
	font-size: 18px;
	text-align: center;
	color: white;
}

a {
	color: blue;
	font-size: 20px;
	padding: 20px 40px;
	background-color: lime;
	text-decoration: none;
	margin-left: 1200px;
	margin-bottom: -60px;
}

a::visisted {
	color: blue;
	font-size: 20px;
	padding: 20px 40px;
	background-color: lime;
	text-decoration: none;
}

a:hover {
	color: black;
	font-size: 20px;
	padding: 20px 40px;
	background-color: rgba(150, 255, 150, 0.5);
	text-decoration: none;
}

h1{
	color: white;
	font-size: 35px;
}

label {
	font-size: 20px;
}
</style>
<body>
<h1>Selamat Datang Admin</h1>

	<a href="index.php">Kembali</a>
	
<form action="proses_loginadmin.php" method="post">
<div class="container">
<img src="book.png">
	<div class="form-input">
	<label>Username : </label><br>
		<input type="text" name="user" placeholder="username" autofocus autocomplete="off">
		</div>
		<div class="form-input">
	<label>Password : </label><br>
		<input type="password" name="pass" placeholder="password" required>
		<div class="form-input">
	
		</div>
		<input type="submit" name="submit" value="Login" class="btn-login">


		</form>



</body>
</html>