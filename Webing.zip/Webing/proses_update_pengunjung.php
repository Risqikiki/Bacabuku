<?php 
require 'function.php';

//ambil data di url
$id = $_GET["id"];
// query data login brdsrkan id
$artikel = query("SELECT * FROM login WHERE id = $id")[0];

// cek submit prnh ditkn blm
if ( isset($_POST["submit"]) ) {

// cek data dubah atau tdk
if (update($_POST) > 0) {
	echo "
	<script>
	alert('data berhasil diubah');
	document.location.href = 'datapengunjung.php';
	</script>";
} else {
	echo "<script>
	alert('data gagal diubah');
	document.location.href = 'update_pengunjung.php';
	</script>";
}
}
?>