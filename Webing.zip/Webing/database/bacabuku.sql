-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 04 Mei 2018 pada 04.22
-- Versi Server: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bacabuku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `artikel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `artikel`) VALUES
(1, 'Bawang Merah Bawang Putih', '<p>Legenda Bawang Merah dan Bawang - Dahulu kala, ada sebuah keluarga yang hidup bahagia. Mereka memiliki seorang puteri yang diberi nama bawang putih. Namun pada suatu hari, ibu bawang putih jatuh sakit dan akhirnya meninggal. Setelah kejadian itu, bawang putih hidup sendiri dengan ayahnya. Ayah bawang putih adalah seorang pedagang yang sering bepergian jauh. Karena tak tega meninggalkan bawang putih sendirian di rumah, akhirnya ayah bawang putih memutuskan menikah lagi dengan seorang janda. Janda tersebut memiliki satu anak yang diberi nama bawang merah.</p>\r\n \r\n<p>Sebenarnya niat ayahnya adalah agar bawang putih tak kesepian dan memiliki teman yang membantunya di rumah. Namun ternyata, ibu dan kakak tiri bawang putih memiliki sifat yang jahat. Mereka bersikap baik pada bawang putih hanya ketika ayahnya ada bersamanya. Namun ketika ayahnya pergi berdagang, mereka menyuruh bawang putih mengerjakan segala pekerjaan rumah seperti seorang pembantu. Ternyata kemalangan bawang putih belum berhenti sampai disitu, selang beberapa waktu, ayah bawang putih juga jatuh sakit dan akhirnya meninggal dunia.</p>\r\n\r\n \r\n<p>Kini, ibu tiri dan bawang merah bersikap semakin jahat pada bawang putih. Bahkan waktu beristirahat bawang putih juga semakin terbatas. Tiap hari dia harus melayani semua kebutuhan bawang merah dan ibu tirinya. Sampai disuatu pagi ketika bawang putih mencuci di sungai, tanpa disadari salah satu selendang kesayangan bawang merah hanyut. Ketika sampai rumah, bawang merah memarahi bawang putih karena selendangnya tak dia temukan. Dia menyuruh bawang putih mencari selendang itu dan tidak boleh pulang sebelum menemukanya. Akhirnya, bawang putih menyusuri sungai untuk mencari selendang itu. Hingga larut malam, selendang itu belum juga dia temukan. Ketika tengah menyusuri sungai, bawang putih nelihat sebuah gubuk, ternyata gubuk itu dihuni oleh seorang nenek sebatang kara. Bawang putih akhirnya meminta izin untuk menginap semalam.</p>\r\n\r\n<p>Nenek itu cukup baik hati, dia mempersilahkan bawang putih untuk menginap. Nenek itu juga menanyakan perihal tentang bawang putih, dan bagaimana dia sampai di tempat itu. Bawang putih pun menceritakan nasib yang dialaminya, hingga nenek yang mendengar itu merasa iba. Ternyata, selendang yang dicari bawang putih ditemukan oleh si nenek. Dan nenek itu mau menyerahkan selendang itu dengan syarat bawang putih harus menemaninya selama seminggu. Bawang putih menerima tawaran itu dengan senang hati.</p>\r\n\r\n<p>Waktu seminggupun berlalu, dan kini waktunya bawang putih untuk pulang. Karena selama tinggal disitu bawang putih sangat rajin, nenek itu memberikan selendang yang dulu dia temukan dan memberi hadiah pada bawang putih. Dia disuruh memilih diantara dua buah labu untuk dia bawa. Awalnya bawang putih ingin menolak, namun karena ingin menghormati pemberian, bawang putih akhirnya memilih labu yang kecil dengan alasan takut tak kuat membawanya. Dan nenek itu hanya tersenyum mendengar alasan itu.</p>\r\n\r\n<p>Setelah itu, bawang putihpun segera pulang dan menyerahkan selendang itu pada bawang merah. Setelah itu dia segera ke dapur untuk membelah labu dan memasaknya. Namun betapa terkejutnya dia, karena ketika labu itu dibelah, ternyata labu itu berisi emas permata yang sangat banyak. Secara tak sengaja, ibu tiri bawang putih melihatnya dan langsung merampas semua emas itu. Bukan hanya itu, dia juga memaksa bawang putih untuk menitakan dari mana dia mendapat labu ajaib itu. Bawang putihpun menceritakan semua kejadian yang dialaminya.</p>\r\n\r\n<p>Mendengar cerita bawang putih, muncul niat jahat di benak ibu tiri yang serakah itu. Esok paginya, dia menyuruh bawang merah untuk melakukan hal yang sama seperti yang silakukan bawang putih, dia berharap akan bisa membawa pulang labu yang lebih besar sehingga isinya lebih banyak.</p>\r\n\r\n<p>Singkat cerita, bawang merah yang malas itu tiba di gubuk nenek, dan diapun tinggal disitu selama seminggu. Namun karena sifatnya yang pemalas, dia hanya bermalas-malasan saja dan tidak mau membantu pekerjaan si nenek. Dan ketika sudah waktunya pulang, diapun di suruh memilih labu sebagai hadiah. Tanpa fikir panjang, dia langsung mengambil labu yang besar dan segera berlari pulang tanpa mengucapkan terimakasih.</p>\r\n\r\n<p>Setelah tiba dirumah, ibunya sangat senang melihat anaknya membawa labu yang sangat besar. Dia berfikir pasti emas di dalamnya cukup banyak. Karena tak ingin diketahui oleh bawang putih dan takut jika bawang putih minta bagian, mereka menyuruh bawang putih mencuci disungai. Setelah itu mereka masuk kamar dan menguncinya dengan rapat.</p>\r\n\r\n<p>Dengan tak sabar, mereka segera membelah labu itu. Namun diluar dugaan, bukan emas yang ada didalamnya. Melainkan labu itu dipenuhi ular, kalajengking, kelabang, dan berbagai hewan berbisa. Dengan cepat hewan-hewan itu keluar dari labu dan menggigit kedua anak dan ibu serakah itu. Mereka tak mampu kabur, karena pintu kamar mereka kunci rapat dan mereka tutup dengan lemari dari dalam. Akhirnya, mereka mati di dalam kamar bersama keserakahan mereka. Setelah mereka mati, hewan-hewan berbisa itu kenyap tak berbekas. Demikian dongeng singkat yang saya ceritakan mengenai cerita anak bawang merah bawang putih semoga bermanfaat.</p>'),
(2, 'Lutung Kasarung', 'Pada jaman dahulu terdapat sebuah Kerajaan yang di pimpin oleh seorang Raja bernama Prabu Tapa Agung.\r\nPrabu Tapa Agung adalah raja tua. Dia memiliki dua anak perempuan, Purbararang dan Purbasari. Prabu Tapa Agung berencana untuk pensiun sebagai raja. Dia ingin Purbasari untuk menggantikannya sebagai pemimpin kerajaan. Mendengar ini, Purbararang marah. \r\n\r\n\r\n&quot;Engkau tidak Bisa menjadikannya seorang ratu  Ayah, aku lebih tua darinya. Seharusnya aku yang menjadi Ratu, Bukan dia!&quot; kata Purbararang. TAPI raja tetap memilih Purbasari Menjadi ratu Selanjutnya.\r\n\r\nPurbararang Lalu mengatur Rencana Jahat dengan tunangannya, Indrajaya. Bersama-sama mereka pergi ke seorang Dukun dan memintanya memantrai Purbasari. Kemudian, kulit Purbasari Menjadi hitam. Ada Banyak bintik-bintik hitam di sekujur tubuhnya. \r\n\r\n\r\n&quot;Kau tak secantik aku. Kau tak bisa menjadi Seorang ratu. Sebagai gantinya, Kau Harus Pergi Dari istana ini dan Tinggal di hutan &quot; kata Purbararang. \r\n\r\n\r\n\r\nPurbasari sangat sedih. Sekarang dia harus tinggal di hutan. Sehari-hari dia habiskan waktunya bermain dengan beberapa binatang di sana. Ada satu monyet yang selalu berusaha menghiburnya. Itu bukan hanya monyet biasa, ia memiliki kekuatan magis. Dan ia juga bisa berbicara dengan manusia. Nama monyet itu adalah Lutung Kasarung. Dia adalah dewa.Namanya Sanghyang Gurumina. Lutung Kasarung direncanakan untuk membantu Purbasari. Dia membuat sebuah danau kecil dan memintanya untuk mandi di sana.Hebatnya, kulit buruk nya sembuh. Sekarang dia punya kulit indah kembali.\r\n\r\nSetelah itu, dia meminta Lutung Kasarung untuk menemaninya kembali ke istana. Purbararang sangat terkejut. Lalu dia  menggunakan rencana jahat yang lain. Dia kemudian berkata, &quot;Mereka yang memiliki rambut panjang akan menjadi ratu itu.&quot; \r\n\r\nRaja kemudian mengukur rambut putrinya. Ternyata Purbasari memiliki rambut yang lebih panjang. Tapi Purbararang tidak menyerah. &quot;Seorang ratu harus memiliki suami yang tampan. Jika tunangan saya lebih tampan dari tunanganmu, maka saya akan menjadi ratu.&quot; kata Purbararang. \r\n\r\nPurbasari sedih. Dia tahu tunangan Purbararang, Indrajaya, tampan. Dan ia tidak memiliki tunangan sama sekali.  Ini adalah tunangan saya, Indrajaya. Mana tunanganmu? &quot; tanya Purbararang. Lutung Kasarung maju. Purbararang tertawa sangat keras. &quot;Tunangan Anda adalah monyet, ha ha ha.&quot; \r\n\r\nTiba-tiba, Lutung Kasarung berubah menjadi sangat tampan. Dia bahkan lebih tampan dari Indrajaya. Purbasari kemudian menjadi ratu. Dia mengampuni Purbararang dan tunangannya dan membiarkan mereka tinggal di istana.\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE `komentar` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `komentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `komentar`
--

INSERT INTO `komentar` (`id`, `username`, `email`, `komentar`) VALUES
(1, 'Risqi Ardiansyah', 'risqi@gmail.com', 'Best!!!!!\r\nTingkatkan!!'),
(2, 'sry', 'serinsry@gmail.com', 'mantap pancing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(8) NOT NULL,
  `notelp` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `notelp`) VALUES
(1, 'Risqi Ardiansyah', '14920', '12345678901'),
(7, 'kikikii', '1234', '12345678904');

-- --------------------------------------------------------

--
-- Struktur dari tabel `loginadmin`
--

CREATE TABLE `loginadmin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `loginadmin`
--

INSERT INTO `loginadmin` (`id`, `username`, `password`) VALUES
(1, 'risqi', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loginadmin`
--
ALTER TABLE `loginadmin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `loginadmin`
--
ALTER TABLE `loginadmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
