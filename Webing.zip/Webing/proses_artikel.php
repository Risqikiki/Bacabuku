<?php 
$koneksi = mysqli_connect('localhost', 'root', '', 'bacabuku');

if (isset($_POST['submit'])) {
	$judul = htmlspecialchars($_POST['judul']);
	$artikel = htmlspecialchars($_POST['isi']);

		$query = "INSERT INTO artikel VALUES ('','$judul','$artikel')";

		$sql   = mysqli_query($koneksi,$query);

		if (mysqli_affected_rows($koneksi)) {
			echo "
					<script>
					alert('Data $judul Berhasil Ditambahkan');
					document.location.href = 'tampil.php';
					</script>";
		}else{
			echo "
				<script>
				alert('Data gagal Ditambahkan');
				document.location.href = 'bawang.php';
				</script>";
		}
	}

?>