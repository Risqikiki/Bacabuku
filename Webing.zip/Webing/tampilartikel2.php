<?php 
require 'function.php';
// koneksi
mysqli_connect("localhost", "root", "", "bacabuku" );
// cek submit prnh ditkn blm
if (isset($_POST["submit"])) {

// cek data dtmbh atau tdk
if (komentar($_POST)>0) {
  echo "
  <script>
  alert('Komentar Anda Ditambahkan');
  document.location.href = 'tampilartikel2.php';
  </script>";
} else {
  echo "<script>
  alert('Komentar Anda Gagal Ditambahkan');
  document.location.href = 'tampilartikel2.php';
  </script>";
}
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Lutung kasarung</title>
</head>
<style>
  @charset "utf-8";
form, fieldset, legend{margin:0; padding:0; border:none;}

#container #respond{display:block; width:100%;}
#container #respond input{width:170px; padding:2px; border:1px solid #CCCCCC; margin:5px 5px 0 0;}
#container #respond textarea{width:98%; border:1px solid #CCCCCC; padding:2px; overflow:auto;}
#container #respond p{margin:5px 0;}
#container #respond #submit, #container #respond #reset{margin:0; padding:5px; color:#666666; background-color:#F7F7F7; border:1px solid #CCCCCC;}

#contactform form{margin:0; padding:0; border:none; line-height:normal;}
#contactform label{display:inline; width:170px; float:left; margin:0 0 12px 0; padding:0;}
#contactform label.margin{margin-left:10px;}
#contactform label input, #contactform label textarea{display:block; width:162px; margin:5px 0; padding:3px; color:#000000; background-color:#F7F7F7; border:1px solid #CCCCCC;}
#contactform label textarea{display:block; width:342px; overflow:auto;}
#contactform p{display:block; width:350px; margin:0; padding:0; clear:both;}
#contactform p input{padding:5px 10px; color:#666666; background-color:#F7F7F7; border:1px solid #CCCCCC;}


html{overflow-y:scroll;}
body{margin:0; padding:0; font-size:13px; font-family:verdana, Arial, Helvetica, sans-serif; color:#FFFFFF; background-color:#4F473A;}

.justify{text-align:justify;}
.bold{font-weight:bold;}
.center{text-align:center;}
.right{text-align:right;}
.nostart{margin:0; padding:0; list-style-type:none;}

.clear{clear:both;}
br.clear{clear:both; margin-top:-15px;}

a{outline:none; text-decoration:none;}

.fl_left, .imgl{float:left;}
.fl_right, .imgr{float:right;}



div.wrapper{display:block; width:100%; margin:0; text-align:left;}
.col1{color:#FFFFFF; background-color:#294E79;}
.col2{color:#666666; background-color:#F5F5F5;}
.col2 a{color:#294E79; background-color:#F5F5F5;}
.col3, .col4{color:#666666; background-color:#FFFFFF;}
.col5{color:#FFFFFF; background-color:#1C3451;}


#head, #gallery, #breadcrumb, #container, #footer{display:block; position:relative; width:960px; margin:0 auto;}

#head{height:110px; z-index:1000;}
#head h1, #head p, #head ul, #head a{margin:0; padding:0; list-style:none; line-height:normal;}
#head h1 a{position:absolute; top:20px; left:0; font-size:38px; font-weight:normal; color:#FFFFFF; background-color:#294E79; font-family:Georgia, "Times New Roman", Times, serif;}
#head p{display:block; position:absolute; top:65px; left:0; color:#F5F5F5; background-color:#294E79; font-size:16px; font-family:Georgia, "Times New Roman", Times, serif;}


#container{padding:40px 0;}
#container h1, #container h2, #container h3, #container h4, #container h5, #container h6{margin:0 0 15px 0; padding:0 0 15px 0; line-height:normal; font-weight:normal; font-size:20px; font-family:Georgia, "Times New Roman", Times, serif; border-bottom:1px dashed #666666;}
#container a{color:#294E79; background-color:#FFFFFF;}


#comments{margin-bottom:40px;}
#comments .commentlist{margin:0; padding:0;}
#comments .commentlist ul{margin:0; padding:0; list-style:none;}
#comments .commentlist li.comment_odd, #comments .commentlist li.comment_even{margin:0 0 10px 0; padding:15px; list-style:none;}
#comments .commentlist li.comment_odd{color:#666666; background-color:#F7F7F7;}
#comments .commentlist li.comment_odd a{color:#294E79; background-color:#F7F7F7;}
#comments .commentlist li.comment_even{color:#666666; background-color:#E8E8E8;}
#comments .commentlist li.comment_even a{color:#294E79; background-color:#E8E8E8;}
#comments .commentlist .author .name{font-weight:bold;}
#comments .commentlist .submitdate{font-size:smaller;}
#comments .commentlist p{margin:10px 5px 10px 0; padding:0; font-weight:normal; text-transform:none;}
#comments .commentlist li .avatar{float:right; border:1px solid #EEEEEE; margin:0 0 0 10px;}




#footer{padding:20px 0;}
#footer a{color:#98B7DC; background-color:#1C3451;}
#footer h2{margin:0 0 15px 0; padding:0 0 8px 0; font-size:22px; font-weight:normal; font-family:Georgia, "Times New Roman", Times, serif; color:#CCCCCC; background-color:#1C3451; line-height:normal; border-bottom:1px dashed #CCCCCC;}
#contactform{display:block; float:left; width:350px;}


#compdetails{display:block; float:right; width:550px;}
#compdetails ul{margin:0; padding:0; list-style:none;}
#compdetails li{margin:0 0 150px 0;}
#compdetails li.last{margin:0;}
#officialdetails{float:left}
#officialdetails li.last{margin-bottom:20px;}
#contactdetails{float:right}


#copyright{display:block; float:left; width:100%; margin:25px 0 0 0; padding:20px 0 0 0; font-size:12px; border-top:1px dashed #666666;}
#copyright p{margin:0; padding:0;}

table{width:100%; border-collapse:collapse; table-layout:auto; vertical-align:top; margin-bottom:15px; border:1px solid #CCCCCC;}
table thead th{color:#FFFFFF; background-color:#666666; border:1px solid #CCCCCC; border-collapse:collapse; text-align:center; table-layout:auto; vertical-align:middle;}
table tbody td{vertical-align:top; border-collapse:collapse; border-left:1px solid #CCCCCC; border-right:1px solid #CCCCCC;}
table thead th, table tbody td{padding:5px; border-collapse:collapse;}
table tbody tr.light{color:#666666; background-color:#F7F7F7;}
table tbody tr.dark{color:#666666; background-color:#E8E8E8;}

.logout {
  text-decoration: none;
  text-align: right;
    margin-left: 1050px;
    margin-bottom: 30px;
    padding-right: 60px;
    padding-left: 20px;
    padding-bottom: 15px;
    padding-top: 15px;
    background-color: tomato;
}

.logout:visited, .kembali:visited {
  color: white;
  background-color: blue;
  text-decoration: none;
}

.logout:hover, .kembali:hover {
  color: black;
  background-color: rgba(255, 100, 100, 0.8);
  text-decoration: none;
}

.kembali {
  text-decoration: none;
  text-align: right;
    margin-left: 950px;
    margin-bottom: 30px;
    padding-right: 60px;
    margin-top: -75px;
    padding-left: 20px;
    padding-bottom: 15px;
    padding-top: 15px;
    background-color: tomato;
}

.utama {
  margin-left: 350px;
  margin-top: -15px;
  background-color: rgba(255, 255, 255, 0.8);
}

.smk {
  margin-left: 0px;
  width: 150px;
  height: 150px;
  float: right;
  margin-right: 20px;
}

.rpl {
  margin-right: 150px;
  margin-left: 45px;
  width: auto;
  height: 150px;
  background-color: rgb(255, 255, 255);

}


</style>

<body id="top">

<?php

  $koneksi = mysqli_connect('localhost','root','','bacabuku');
  $query = "SELECT * FROM artikel WHERE id = 2";
  $sql = mysqli_query($koneksi,$query);

  while ($data= mysqli_fetch_assoc($sql)) {
    
  
 ?>

<div class="wrapper col1">
  <div id="head">
    <h1><a>Legenda Lutung Kasarung</a></h1>
    <p>Cerita Singkat</p>

 <div class="logout">
  <a href="logout.php"; onclick="return confirm('Apakah Anda Yakin Ingin Keluar?')";>Logout</a>   
</div>

<div class="kembali">
<a href="Baca.php">Home</a>
</div>
    </div>
  </div>
</div>

<div class="wrapper col4">
  <div id="container">
    <h1><?php echo $data['judul']; ?></h1>
    <img class="utama" src="Lutung Kasarung.jpg">
    <p><?php echo $data['artikel']; ?></p>

<?php } ?>
  </div>
</div>    
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>Ada Kritik Atau Saran?</h2>
      <form action="" method="post">
        <fieldset>
          <legend>Form Komentar</legend><br>
          <label for="fullname">Username :
            <input id="fullname" name="username" type="text"/>
          </label>
          <label for="emailaddress" class="margin">Email :
            <input id="emailaddress" name="email" type="text"/>
          </label>
          <label for="message">Komentar :<br />
            <textarea id="message" name="komentar" cols="40" rows="4"></textarea>
          </label>
          <p>
            <input id="submitform" name="submit" type="submit" value="Submit" />
            &nbsp;
            <input id="resetform" name="reset" type="reset" value="Reset" />
          </p>
        </fieldset>
      </form>
    </div>

    <div id="compdetails">
      <div id="officialdetails">
        <h2 style="text-align: center;">My School !</h2>
        <ul>
          <li><img class="smk" src="SMK N 1 Bawang.jpg"><img class="rpl" src="rpl.jpg"></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
<div id="mbuh">
      <div id="embuh">
        <h2>Tentang Saya !</h2>
        <ul>
          <li>Risqi Ardiansyah</li>
          <li>X Rekayasa Perangkat Lunak 2</li>
          <li>WA. 083862265812</li>
          <li class="last">ig. @_risqiard_</li>
        </ul>
        <h2>Alamat Tempat Tinggal Saya !</h2>
        <p><a>Parakancanggah, RT 04/05</a> | <a>Banjarnegara</a></p>
      </div>
      <div class="mboh"></div>
    </div>
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a>Banjarnegara</a></p>
      <p class="fl_right">Dibuat Oleh : <a> Risqi Ardiansyah</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>