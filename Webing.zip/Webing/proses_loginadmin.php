<?php 
	$koneksi = new mysqli('localhost','root','','bacabuku');

	
		$user   = htmlspecialchars($_POST['user']);
		$pass   = htmlspecialchars($_POST['pass']);

		$query = $koneksi->query("SELECT * FROM loginadmin WHERE password='$pass'");

		$cek   = $query->num_rows;

		if ($cek == 1) {

			session_start();
			$_SESSION['user']= $query->fetch_assoc();
			echo "
					<script>
					alert('Selamat Datang $user');
					document.location.href = 'homepage.php';
					</script>";
		}else{
			
			echo "
					<script>
					alert('Password atau Username Salah');
					document.location.href = 'login_admin.php';
					</script>";
			
		}
	

 ?>