<?php
	require 'function.php';
	$id = $_GET['id'];

	$art = query("SELECT * FROM artikel WHERE id = $id")[0];
	

?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<style>

body {
	background-image: url(b.jpg);
	background-attachment: fixed;
	background-size: inherit;
}
h1 {
	text-align: center;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;
	margin-left: 280px;
}

form {
	margin-left: 350px;
	font-family: tahoma;
}

.abc {
	font-size: 25px;
	color: blue;
	text-decoration: none;
	text-align: right;
	padding : 40px;
	padding-top: 20px;
	padding-bottom: 20px;
    margin-left: 1150px;
    margin-top: -70px;	
    width: 100px;
	height: 25px;
}

footer {
	background-color: white;
	text-align: center;
	font-size: 20px;
	margin-top: 150px;
	height: 100px;
}
</style>
<body>

<h1>Ubah Data Artikel</h1>
<div class="abc">
<a href="tampil.php">Kembali</a>
</div>

<form action="proses_update.php" method="post">
	<input type="hidden" name="id" value="<?= $art["id"]; ?>">
		<label>Judul : </label><br>
			<textarea type="text" name="judul" id="judul" cols="50" rows="1"><?= $art["judul"]; ?></textarea><br>
		<label>Artikel : </label><br>
			<textarea type="text" name="artikel" id="artikel" cols="100" rows="30"><?= $art["artikel"]; ?></textarea>
			<br>
			<br>

	<button type="submit" name="submit" class="btn-login">Ubah data</button>
</form>

<footer>
	<p>&copy;Risqi Ardiansyah
	<br>
	SMK N 1 Bawang
	<br>
	Banjarnegara, Jawa Tengah</p>
</footer>

</body>
</html>