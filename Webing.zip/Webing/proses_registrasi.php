<?php 
	$koneksi = mysqli_connect('localhost','root','','bacabuku');

	if (isset($_POST['submit'])) {
		$user = htmlspecialchars($_POST['user']);
		$pass = htmlspecialchars($_POST['pass']);
		$notelp   = htmlspecialchars($_POST['notelp']);

		$query = "INSERT INTO login VALUES ('','$user','$pass','$notelp')";

		$sql   = mysqli_query($koneksi,$query);

		if (mysqli_affected_rows($koneksi)) {
			echo "
					<script>
					alert('Pendaftaran Sukses Sebagai $user');
					document.location.href = 'Baca.php';
					</script>";
		}else{
			echo "
				<script>
				alert('Pendaftaran gagal');
				document.location.href = 'registrasi.php';
				</script>";
		}
	}

 ?>