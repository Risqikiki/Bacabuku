<?php 
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "bacabuku");



function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while($row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

// hapus data artikel
function hapus($id) {
 	global $conn;
 	mysqli_query($conn, "DELETE FROM artikel WHERE id = $id");
 	return mysqli_affected_rows($conn);
}

//tambah komentar
function komentar($data) {
	global $conn;
	//ambil data tiap elemen form
	$username = htmlspecialchars($data["username"]);
	$email = htmlspecialchars($data["email"]);
	$komentar = htmlspecialchars($data["komentar"]);

	//query insert data
	$query = "INSERT INTO komentar
	VALUES
	('', '$username', '$email', '$komentar')";


	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

//hapus komentar
function hps($id) {
 	global $conn;
 	mysqli_query($conn, "DELETE FROM komentar WHERE id = $id");
 	return mysqli_affected_rows($conn);
}

//hapus data pengunjung
function delete($id) {
 	global $conn;
 	mysqli_query($conn, "DELETE FROM login WHERE id = $id");
 	return mysqli_affected_rows($conn);
}

//ubah artikel
function ubah($data) {
	global $conn;
		//ambil data tiap elemen form
	$id = $data["id"];
	$judul = htmlspecialchars($data["judul"]);
	$artikel = htmlspecialchars($data["artikel"]);

	//query insert data
	$query = "UPDATE artikel SET
			judul = '$judul',
			artikel = '$artikel'
		WHERE id = $id
		";


	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}


//ubah data pengunjung
function update($data) {
	global $conn;
		//ambil data tiap elemen form
	$id = $data["id"];
	$username = htmlspecialchars($data["username"]);
	$password = htmlspecialchars($data["password"]);
	$notelp = htmlspecialchars($data["notelp"]);

	//query insert data
	$query = "UPDATE login SET
			username = '$username',
			password = '$password',
			notelp   = '$notelp'
		WHERE id = $id
		";


	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

//pencarian artikel
function cari($keyword) {
	$query = "SELECT * FROM artikel
	WHERE judul LIKE '%$keyword%' 
	OR artikel LIKE '%$keyword%' 
	";

	return query($query);
}

//pencarian pengunjung
function search($keyword) {
	$query = "SELECT * FROM login
	WHERE username LIKE '%$keyword%' 
	OR password LIKE '%$keyword%'
	OR notelp LIKE '%$keyword%' 
	";

	return query($query);
}

//pencarian komentar
function src($keyword) {
	$query = "SELECT * FROM komentar
	WHERE username LIKE '%$keyword%' 
	OR email LIKE '%$keyword%'
	OR komentar LIKE '%$keyword%' 
	";

	return query($query);
}
?>