<!DOCTYPE html>
<html>
<head>
	<title>Registrasi</title>
</head>
<style>
	body {
		margin: 0 auto;
		background-image: url(bgwebb.jpg);
		background-repeat: no-repeat;
		background-size: 100% 720px;
	}

h1 {
	text-align: center;
	font-size: 50px;
}

.container {
	width: 550px;
	height: 450px;
	text-align: center;
	background-color: rgba(200,200,200,0.7);
	border-radius: 4px;
	margin: 0 auto;
	margin-top: 100px;
}
.container img {
	width: 120px;
	height: 120px;
	margin-top: -60px;
	margin-bottom: 30px;

}
input[type="text"],input[type=password]{
	height: 45px;
	width: 300px;
	font-size: 16px;
	border: none;
	margin-bottom: 20px;
	border-radius: 4px;
	background-color: #fff;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;

}

.foot {
	width: 150px;
	padding-left: 580px;
	padding-right: 550px;
	background-color: white;
	margin-top: 130px;
	margin-left: 20px;
	margin-right: 20px;
	float: left;
}
.foot2 {
	width: 150px;
	padding-left: 580px;
	padding-right: 550px;
	background-color: white;
	margin-left: 20px;
	margin-right: 20px;
}

p {
	text-align: center;
	background-color: white;
	margin-top: 200px;
	font-size: 20px;
	height: 100px;
}

p1 {
	font-size: 15px;
	text-align: center;
	color: white;
}

a {
	font-size: 18px;
}

h1{
	color: white;
	font-size: 35px;
}

label {
	font-size: 20px;
}
</style>
<body>

<h1>Buat Akun Anda Disini!</h1>

	<form action="proses_registrasi.php" method="post">
<div class="container">
<img src="book.png">
	<div class="form-input">
	<label>Username : </label><br>
		<input type="text" name="user" placeholder="username" autofocus required>
		</div>
		<div class="form-input">
	<label>Password ; </label><br>
		<input type="password" name="pass" placeholder="password" required>
		<div class="form-input">
	<label>No. Telepon : </label><br>
	<input type="text" name="notelp" placeholder="no.telpon">
	
		</div>
		<input type="submit" name="submit" value="Buat Akun" class="btn-login">

		</form>

	<p1>Sudah Punya Akun? </p1>
	<a href="index.php"> LOGIN</a>

<footer>
	<p>&copy;Risqi Ardiansyah
	<br>
	SMK N 1 Bawang
	<br>
	Banjarnegara, Jawa Tengah</p>
</footer>

</body>
</html>