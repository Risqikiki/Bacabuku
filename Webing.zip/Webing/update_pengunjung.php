<?php
	require 'function.php';
	$id = $_GET['id'];

	$art = query("SELECT * FROM login WHERE id = $id")[0];
	

?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<style>

body {
	background-image: url(b.jpg);
	background-attachment: fixed;
	background-size: inherit;
}
h1 {
	text-align: center;
	font-size: 50px;
}

.container {
	margin-left: 250px;
	border: 2px solid #848484;
	border-radius:20px;
	-moz-border-radius:20px;
	max-height: 90%;
	font-weight: bold;
	color: #606060;
	padding: 10px;
	width: 800px;
	background-color: #dcdcdc;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;

}



footer {
	background-color: white;
	text-align: center;
	font-size: 20px;
	margin-top: 500px;
	height: 100px;
}
</style>
<body>
<h1>Ganti User</h1>

<form action="proses_update_pengunjung.php" method="post" class="container">
	<input  type="hidden" name="id" value="<?= $art["id"]; ?>">
	<ul>
		<li>
			<label>Username : </label><br>
			<input style="padding: 5px 12px; border-radius: 7px;color: black;" 
			type="text" name="username" required
			value="<?= $art["username"]; ?>">
		</li>
		<li>
			<label>Password  :  </label><br>
			<input style="padding: 5px 12px; border-radius: 7px;color: black;" type="password" name="password" required
			value="<?= $art["password"]; ?>">
		</li>
		<li>
			<label>No.telp   :  </label><br>
			<input style="padding: 5px 12px; border-radius: 7px;color: black;" type="text" name="notelp"
			value="<?= $art["notelp"]; ?>"><br><br>
		</li>
		<li>
			<button type="submit" name="submit" class="btn-login">Ubah data</button>
		</li>
	</ul>

</form>

<footer>
	<p>&copy;Risqi Ardiansyah
	<br>
	SMK N 1 Bawang
	<br>
	Banjarnegara, Jawa Tengah</p>
</footer>

</body>
</html>