<?php 
	session_start();
	if (isset($_SESSION['user'])) {
		header("LOCATION:Baca.php");
	}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style>
body { margin: 0 auto; background-image: url(bgwebb.jpg); background-repeat: no-repeat; background-size: 100% 720px;}

h1 { text-align: center; font-size: 50px;}

.container {width: 550px;height: 500px;text-align: center;background-color: rgba(200,200,200,0.7);border-radius: 4px;margin: 0 auto;margin-top: 60px;
}
.container img {width: 120px;height: 120px;margin-top: -60px;margin-bottom: 30px;

}
input[type="text"],input[type=password]{height: 45px;width: 300px;font-size: 16px;border: none;margin-bottom: 20px;border-radius: 4px;background-color: #fff;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;

}


p {
	text-align: center;
	background-color: white;
	margin-top: 200px;
	font-size: 20px;
	height: 100px;
	text-decoration: none;
}

p1 {
	font-size: 18px;
	text-align: center;
	color: black;
}

a {
	font-size: 20px;
	text-decoration: none;
	color: blue;
}
a::visited {
	font-size: 20px;
	text-decoration: none;
	color: blue;
	background-color: green;
}

a:hover {
	font-size: 20px;
	text-decoration: none;
	color: maroon;
}
h1{
	color: white;
	font-size: 35px;
}

label {
	font-size: 20px;
}

.admin {
	color: blue;
	font-size: 20px;
	padding: 20px;
	width: 60px;
	background-color: lime;
	text-decoration: none;
	margin-left: 1200px;
	margin-bottom: -60px;
}

.admin::visisted {
	color: blue;
	font-size: 20px;
	padding: 20px;
	width: 60px;
	background-color: lime;
	text-decoration: none;
}

.admin:hover {
	color: black;
	font-size: 20px;
	padding: 20px;
	width: 60px;
	background-color: rgba(150, 255, 150, 0.5);
	text-decoration: none;
}

footer {
	margin-top: 100px;
}
</style>
<body>
<h1>Selamat Datang Di Web Baca Buku<br>
Masukan Akun Yang Sudah Anda Buat</h1>

<div class="admin">
	<a href="login_admin.php">Admin</a>
</div>

<form action="proses_login.php" method="post">
<div class="container">
<img src="book.png">
	<div class="form-input">
	<label>Username : </label><br>
		<input type="text" name="user" placeholder="username" autofocus required autocomplete="off">
		</div>
		<div class="form-input">
	<label>Password : </label><br>
		<input type="password" name="pass" placeholder="password" required="">
		<div class="form-input">
	<label>No. Telepon : </label><br>
	<input type="text" name="notelp" placeholder="no.telpon" autocomplete="off">
	
		</div>
		<input type="submit" name="submit" value="Login" class="btn-login">


		</form>

	<br><p1>Belum Punya Akun? </p1><br>

	<a href="registrasi.php"> Daftar</a>
	
<footer>
	<p>&copy;Risqi Ardiansyah
	<br>
	SMK N 1 Bawang
	<br>
	Banjarnegara, Jawa Tengah</p>
</footer>

</body>
</html>