<!DOCTYPE html>
<html>
<head>
	<title>Legenda Bawang Merah Bawang Putih</title>
</head>
<style>

body {
	background-image: url(c.jpg);
	background-attachment: fixed;
	background-size: inherit;
}
h1 {
	text-align: center;
}

footer {
	background-color: white;
	text-align: center;
	font-size: 20px;
	margin-top: 150px;
	height: 100px;
}

.container {
	margin-left: 250px;
	border: 2px solid #848484;
	border-radius:20px;
	-moz-border-radius:20px;
	max-height: 90%;
	font-weight: bold;
	color: #606060;
	padding: 10px;
	width: 800px;
	background-color: #dcdcdc;
}

.form-input {
	font-size: 25px;
}

.btn-login {
	padding: 10px 30px;
	color: white;
	border-radius: 4px;
	border: none;
	background-color: lime;

}

</style>
<body>
<?php

	$koneksi = mysqli_connect('localhost','root','','bacabuku');
	$query = "SELECT * FROM artikel";
	$sql = mysqli_query($koneksi,$query);

	$data= mysqli_fetch_assoc($sql);
		
	
 ?>

 <h1>Tambah Data Artikel</h1>

	<form action="proses_artikel.php" method="post" name="form">
<div class="container">
	<div class="form-input">
	<label>Judul Artikel </label><br>
		<textarea type="text" name="judul" autofocus cols="50" ></textarea>
		</div>
		<div class="form-input">
	<label>Isi Artikel </label><br>
		<textarea type="text" name="isi" required cols="100" rows="30"></textarea>
	
</div>
		<input type="submit" name="submit" value="Simpan" class="btn-login">
</div>
		</form>

<footer>
	<p>&copy;Risqi Ardiansyah
	<br>
	SMK N 1 Bawang
	<br>
	Banjarnegara, Jawa Tengah</p>
</footer>

</body>
</html>